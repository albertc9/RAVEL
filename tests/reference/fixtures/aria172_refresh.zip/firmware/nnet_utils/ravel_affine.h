#ifndef RAVEL_AFFINE_H_
#define RAVEL_AFFINE_H_
struct ravel_matrix_conv2d_1 {
template<class SCALAR, class MULT>
static void apply(SCALAR *input, typename MULT::accum_t *output) {
#pragma HLS INLINE
typedef ap_int<15> code_t;
ap_int<9> x0_raw;
x0_raw.range(8, 0) = input[0].range(8, 0);
code_t x0 = x0_raw;
ap_int<9> x1_raw;
x1_raw.range(8, 0) = input[1].range(8, 0);
code_t x1 = x1_raw;
ap_int<9> x2_raw;
x2_raw.range(8, 0) = input[2].range(8, 0);
code_t x2 = x2_raw;
ap_int<9> x3_raw;
x3_raw.range(8, 0) = input[3].range(8, 0);
code_t x3 = x3_raw;
ap_int<9> x4_raw;
x4_raw.range(8, 0) = input[4].range(8, 0);
code_t x4 = x4_raw;
ap_int<9> x5_raw;
x5_raw.range(8, 0) = input[5].range(8, 0);
code_t x5 = x5_raw;
ap_int<9> x6_raw;
x6_raw.range(8, 0) = input[6].range(8, 0);
code_t x6 = x6_raw;
ap_int<9> x7_raw;
x7_raw.range(8, 0) = input[7].range(8, 0);
code_t x7 = x7_raw;
ap_int<9> x8_raw;
x8_raw.range(8, 0) = input[8].range(8, 0);
code_t x8 = x8_raw;
ap_int<9> x9_raw;
x9_raw.range(8, 0) = input[9].range(8, 0);
code_t x9 = x9_raw;
ap_int<9> x10_raw;
x10_raw.range(8, 0) = input[10].range(8, 0);
code_t x10 = x10_raw;
ap_int<9> x11_raw;
x11_raw.range(8, 0) = input[11].range(8, 0);
code_t x11 = x11_raw;
ap_int<9> x12_raw;
x12_raw.range(8, 0) = input[12].range(8, 0);
code_t x12 = x12_raw;
ap_int<9> x13_raw;
x13_raw.range(8, 0) = input[13].range(8, 0);
code_t x13 = x13_raw;
ap_int<9> x14_raw;
x14_raw.range(8, 0) = input[14].range(8, 0);
code_t x14 = x14_raw;
code_t x0_shift3 = x0 << 3;
code_t x0_shift1 = x0 << 1;
code_t x0_c6_negative1 = x0_shift3 - x0_shift1;
code_t x1_shift3 = x1 << 3;
code_t x1_shift1 = x1 << 1;
code_t x1_c6_negative1 = x1_shift3 - x1_shift1;
code_t x3_shift2 = x3 << 2;
code_t x3_c_4_negate = -x3_shift2;
code_t x4_shift1 = x4 << 1;
code_t x5_shift3 = x5 << 3;
code_t x5_c7_negative1 = x5_shift3 - x5;
code_t x6_shift3 = x6 << 3;
code_t x6_shift1 = x6 << 1;
code_t x6_c6_negative1 = x6_shift3 - x6_shift1;
code_t x7_shift2 = x7 << 2;
code_t x7_c_5_negate = -x7;
code_t x7_c_5_negative1 = x7_c_5_negate - x7_shift2;
code_t x8_shift2 = x8 << 2;
code_t x9_c_1_negate = -x9;
code_t x10_shift2 = x10 << 2;
code_t x10_c5_positive1 = x10 + x10_shift2;
code_t x12_shift2 = x12 << 2;
code_t x12_c_5_negate = -x12;
code_t x12_c_5_negative1 = x12_c_5_negate - x12_shift2;
code_t x13_c_1_negate = -x13;
code_t x0_c_6_negative1 = x0_shift1 - x0_shift3;
code_t x2_shift1 = x2 << 1;
code_t x2_c_2_negate = -x2_shift1;
code_t x5_shift2 = x5 << 2;
code_t x5_c5_positive1 = x5 + x5_shift2;
code_t x6_shift2 = x6 << 2;
code_t x6_c_4_negate = -x6_shift2;
code_t x7_c_4_negate = -x7_shift2;
code_t x9_shift1 = x9 << 1;
code_t x9_c_2_negate = -x9_shift1;
code_t x10_shift3 = x10 << 3;
code_t x10_c7_negative1 = x10_shift3 - x10;
code_t x12_shift1 = x12 << 1;
code_t x13_shift2 = x13 << 2;
code_t x13_c_3_negative1 = x13 - x13_shift2;
code_t x14_shift2 = x14 << 2;
code_t x14_c_5_negate = -x14;
code_t x14_c_5_negative1 = x14_c_5_negate - x14_shift2;
code_t x1_c_1_negate = -x1;
code_t x2_shift3 = x2 << 3;
code_t x2_c7_negative1 = x2_shift3 - x2;
code_t x3_c_3_negative1 = x3 - x3_shift2;
code_t x4_shift3 = x4 << 3;
code_t x4_c_6_negative1 = x4_shift1 - x4_shift3;
code_t x7_c_3_negative1 = x7 - x7_shift2;
code_t x8_shift1 = x8 << 1;
code_t x8_shift3 = x8 << 3;
code_t x8_c_6_negative1 = x8_shift1 - x8_shift3;
code_t x9_shift2 = x9 << 2;
code_t x9_c5_positive1 = x9 + x9_shift2;
code_t x10_c_1_negate = -x10;
code_t x12_shift3 = x12 << 3;
code_t x12_c6_negative1 = x12_shift3 - x12_shift1;
code_t x13_shift1 = x13 << 1;
code_t x13_c_2_negate = -x13_shift1;
code_t cse0 = x11 + x8_shift2;
code_t y0_f0_tree0_0 = x0_c6_negative1 + x1_c6_negative1;
code_t y0_f0_tree0_2 = x2 + x3_c_4_negate;
code_t y0_f0_tree0_4 = x4_shift1 + x5_c7_negative1;
code_t y0_f0_tree0_6 = x6_c6_negative1 + x7_c_5_negative1;
code_t y0_f0_tree0_8 = x10_c5_positive1 + x9_c_1_negate;
code_t y0_f0_tree0_10 = x12_c_5_negative1 + x13_c_1_negate;
code_t y0_f0_tree0_12 = cse0 + x14;
code_t y0_f0_tree1_0 = y0_f0_tree0_0 + y0_f0_tree0_2;
code_t y0_f0_tree1_2 = y0_f0_tree0_4 + y0_f0_tree0_6;
code_t y0_f0_tree1_4 = y0_f0_tree0_10 + y0_f0_tree0_8;
code_t y0_f0_tree2_0 = y0_f0_tree1_0 + y0_f0_tree1_2;
code_t y0_f0_tree2_2 = y0_f0_tree0_12 + y0_f0_tree1_4;
code_t y0_f0_tree3_0 = y0_f0_tree2_0 + y0_f0_tree2_2;
code_t y0_f1_tree0_0 = x0_c_6_negative1 + x2_c_2_negate;
code_t y0_f1_tree0_2 = x3_shift2 + x5_c5_positive1;
code_t y0_f1_tree0_4 = x6_c_4_negate + x7_c_4_negate;
code_t y0_f1_tree0_6 = x10_c7_negative1 + x9_c_2_negate;
code_t y0_f1_tree0_8 = x12_shift1 + x13_c_3_negative1;
code_t y0_f1_tree0_10 = cse0 + x14_c_5_negative1;
code_t y0_f1_tree1_0 = y0_f1_tree0_0 + y0_f1_tree0_2;
code_t y0_f1_tree1_2 = y0_f1_tree0_4 + y0_f1_tree0_6;
code_t y0_f1_tree1_4 = y0_f1_tree0_10 + y0_f1_tree0_8;
code_t y0_f1_tree2_0 = y0_f1_tree1_0 + y0_f1_tree1_2;
code_t y0_f1_tree3_0 = y0_f1_tree1_4 + y0_f1_tree2_0;
code_t y0_f2_tree0_0 = x0 + x1_c_1_negate;
code_t y0_f2_tree0_2 = x2_c7_negative1 + x3_c_3_negative1;
code_t y0_f2_tree0_4 = x4_c_6_negative1 + x5_shift2;
code_t y0_f2_tree0_6 = x7_c_3_negative1 + x8_c_6_negative1;
code_t y0_f2_tree0_8 = x10_c_1_negate + x9_c5_positive1;
code_t y0_f2_tree0_10 = x12_c6_negative1 + x13_c_2_negate;
code_t y0_f2_tree1_0 = y0_f2_tree0_0 + y0_f2_tree0_2;
code_t y0_f2_tree1_2 = y0_f2_tree0_4 + y0_f2_tree0_6;
code_t y0_f2_tree1_4 = y0_f2_tree0_10 + y0_f2_tree0_8;
code_t y0_f2_tree2_0 = y0_f2_tree1_0 + y0_f2_tree1_2;
code_t y0_f2_tree2_2 = x14 + y0_f2_tree1_4;
code_t y0_f2_tree3_0 = y0_f2_tree2_0 + y0_f2_tree2_2;
output[0].range(14, 0) = y0_f0_tree3_0.range(14, 0);
output[1].range(14, 0) = y0_f1_tree3_0.range(14, 0);
output[2].range(14, 0) = y0_f2_tree3_0.range(14, 0);
}
};

namespace ravel {
template<class IN, class OUT, class CONFIG, unsigned POSITIONS, class ARITHMETIC>
void scheduled_affine_conv(hls::stream<IN>& input, hls::stream<OUT>& output) {
    typedef typename IN::value_type scalar;
    typedef typename OUT::value_type result;
    typedef typename CONFIG::mult_config MULT;
    static scalar history[CONFIG::filt_height][CONFIG::in_width][CONFIG::n_chan];
    #pragma HLS ARRAY_PARTITION variable=history complete dim=0
    unsigned row=0, column=0, phase=0;
AffineWords:
    for (unsigned word=0; word<CONFIG::in_height*CONFIG::in_width/POSITIONS; ++word) {
        #pragma HLS PIPELINE II=1
        IN incoming=input.read();
        scalar window[POSITIONS][CONFIG::filt_height*CONFIG::n_chan];
        #pragma HLS ARRAY_PARTITION variable=window complete dim=0
        for(unsigned position=0; position<POSITIONS; ++position) {
            #pragma HLS UNROLL
            for(unsigned tap=0; tap<CONFIG::filt_height; ++tap) {
                #pragma HLS UNROLL
                for(unsigned channel=0; channel<CONFIG::n_chan; ++channel) {
                    #pragma HLS UNROLL
                    window[position][tap*CONFIG::n_chan+channel] =
                        tap+1==CONFIG::filt_height ? incoming[position*CONFIG::n_chan+channel]
                        : history[tap+1][column+position][channel];
                    history[tap][column+position][channel]=window[position][tap*CONFIG::n_chan+channel];
                }
            }
        }
        if(row+1>=CONFIG::filt_height && phase==0) {
            OUT outgoing;
            #pragma HLS ARRAY_PARTITION variable=outgoing complete dim=0
            for(unsigned position=0; position<POSITIONS; ++position) {
                #pragma HLS UNROLL
                typename MULT::accum_t sums[MULT::n_out];
                #pragma HLS ARRAY_PARTITION variable=sums complete dim=0
                ARITHMETIC::template apply<scalar, MULT>(window[position], sums);
                for(unsigned f=0; f<MULT::n_out; ++f) {
                    #pragma HLS UNROLL
                    outgoing[position*CONFIG::n_filt+f]=nnet::cast<scalar,result,MULT>(sums[f]);
                }
            }
            output.write(outgoing);
        }
        column+=POSITIONS;
        if(column==CONFIG::in_width) {
            column=0;
            ++row;
            if(row>=CONFIG::filt_height)
                phase=phase+1==CONFIG::stride_height ? 0 : phase+1;
        }
    }
}
// A fixed number of position engines processes one accepted word in phases.
// The external word width and order are independent of arithmetic reuse.
template<class IN, class OUT, class CONFIG, unsigned POSITIONS, class ARITHMETIC, unsigned REUSE>
void shared_conv(hls::stream<IN>& input, hls::stream<OUT>& output) {
    static_assert(POSITIONS % REUSE == 0, "Reuse must divide position lanes");
    typedef typename IN::value_type scalar;
    typedef typename OUT::value_type result;
    typedef typename CONFIG::mult_config MULT;
    const unsigned ENGINES = POSITIONS / REUSE;
    const unsigned STEPS = (CONFIG::in_height + CONFIG::out_height * (REUSE - 1)) * CONFIG::in_width / POSITIONS;
    static scalar history[CONFIG::filt_height][CONFIG::in_width][CONFIG::n_chan];
    scalar window[POSITIONS][CONFIG::filt_height*CONFIG::n_chan];
    OUT outgoing;
    #pragma HLS ARRAY_PARTITION variable=history complete dim=0
    #pragma HLS ARRAY_PARTITION variable=window complete dim=0
    #pragma HLS ARRAY_PARTITION variable=outgoing complete dim=0
    unsigned row=0, column=0, phase=0, reuse_phase=0;
ReusePhases:
    for (unsigned step=0; step<STEPS; ++step) {
        #pragma HLS PIPELINE II=1
        bool ready = row+1>=CONFIG::filt_height && phase==0;
        if (reuse_phase==0) {
            IN incoming=input.read();
            for(unsigned position=0; position<POSITIONS; ++position) {
                #pragma HLS UNROLL
                for(unsigned tap=0; tap<CONFIG::filt_height; ++tap) {
                    #pragma HLS UNROLL
                    for(unsigned channel=0; channel<CONFIG::n_chan; ++channel) {
                        #pragma HLS UNROLL
                        window[position][tap*CONFIG::n_chan+channel] =
                            tap+1==CONFIG::filt_height ? incoming[position*CONFIG::n_chan+channel]
                            : history[tap+1][column+position][channel];
                        history[tap][column+position][channel]=window[position][tap*CONFIG::n_chan+channel];
                    }
                }
            }
        }
        if(ready) {
            for(unsigned engine=0; engine<ENGINES; ++engine) {
                #pragma HLS UNROLL
                typename MULT::accum_t sums[MULT::n_out];
                #pragma HLS ARRAY_PARTITION variable=sums complete dim=0
                unsigned position=reuse_phase*ENGINES+engine;
                ARITHMETIC::template apply<scalar, MULT>(window[position], sums);
                for(unsigned f=0; f<MULT::n_out; ++f) {
                    #pragma HLS UNROLL
                    outgoing[position*CONFIG::n_filt+f]=nnet::cast<scalar,result,MULT>(sums[f]);
                }
            }
            if(reuse_phase+1==REUSE) output.write(outgoing);
        }
        if(!ready || reuse_phase+1==REUSE) {
            reuse_phase=0;
            column+=POSITIONS;
            if(column==CONFIG::in_width) {
                column=0;
                ++row;
                if(row>=CONFIG::filt_height)
                    phase=phase+1==CONFIG::stride_height ? 0 : phase+1;
            }
        } else ++reuse_phase;
    }
}

}

#endif
