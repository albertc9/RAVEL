#ifndef RAVEL_W11_PACKED_H_
#define RAVEL_W11_PACKED_H_

#include "ap_int.h"

const ap_uint<60> w11_ravel_packed[6] = {
    ap_uint<60>("0x10f810f400e83c2", 16),
    ap_uint<60>("0x2005ce7ba3f0f7e", 16),
    ap_uint<60>("0xe83bef139cf101f", 16),
    ap_uint<60>("0x08c1ce8be0f0842", 16),
    ap_uint<60>("0x0ffe4013bde0ffd", 16),
    ap_uint<60>("0xf1001f080127800", 16)
};

#endif
