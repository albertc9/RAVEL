//Numpy array shape [5, 1, 1, 3]
//Min -0.562500000000
//Max 0.500000000000
//Number of zeros 2

#ifndef W3_H_
#define W3_H_

#ifndef __SYNTHESIS__
calibration_conv_0_weight_t w3[15];
#else
calibration_conv_0_weight_t w3[15] = {-0.1250, 0.5000, -0.5625, 0.0625, -0.0625, 0.0000, -0.1250, -0.0625, -0.5000, 0.5000, -0.5000, 0.5000, -0.1250, 0.0000, 0.5000};

#endif

#endif
