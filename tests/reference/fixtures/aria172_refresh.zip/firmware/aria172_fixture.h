#ifndef ARIA172_FIXTURE_H_
#define ARIA172_FIXTURE_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "hls_stream.h"

#include "defines.h"

void aria172_fixture(
    hls::stream<calibration_input_x8_t> &calibration_input,
    hls::stream<result_t> &layer11_out
);

#endif
