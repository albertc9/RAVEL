#include "aria172_fixture.h"
#include "parameters.h"
#include "nnet_utils/nnet_aria.h"
#include "nnet_utils/ravel_bridges.h"
#include "weights/w11_ravel_packed.h"
#include "nnet_utils/ravel_windows.h"
#include "nnet_utils/ravel_affine.h"
void aria172_fixture(hls::stream<calibration_input_x8_t> &calibration_input, hls::stream<result_t> &layer11_out) {
    #pragma HLS INTERFACE axis port=calibration_input,layer11_out
    #pragma HLS DATAFLOW
#ifndef __SYNTHESIS__
    static bool loaded = false;
    if (!loaded) {
        nnet::load_weights_from_txt<calibration_conv_0_bias_t, 3>(b3, "b3.txt");
        nnet::load_weights_from_txt<calibration_conv_0_weight_t, 15>(w3, "w3.txt");
        nnet::load_weights_from_txt<calibration_conv_1_bias_t, 3>(b7, "b7.txt");
        nnet::load_weights_from_txt<calibration_conv_1_weight_t, 45>(w7, "w7.txt");
        nnet::load_weights_from_txt<calibration_head_bias_t, 1>(b11, "b11.txt");
        nnet::load_weights_from_txt<calibration_head_weight_t, 72>(w11, "w11.txt");
        loaded = true;
    }
#endif
    hls::stream<calibration_pool_0_x4_t> layer5_out_x4("layer5_out_x4");
    #pragma HLS STREAM variable=layer5_out_x4 depth=4
    hls::stream<ravel_conv2d_1_window_t> layer7_out("layer7_out");
    #pragma HLS STREAM variable=layer7_out depth=4
    hls::stream<ravel_relu_1_window_t> layer8_out("layer8_out");
    #pragma HLS STREAM variable=layer8_out depth=4
    hls::stream<ravel_max_pool2d_1_window_t> layer9_out("layer9_out");
    #pragma HLS STREAM variable=layer9_out depth=4
    nnet::phara_pool_aligned_hybrid_p8_cl<calibration_input_x8_t, calibration_conv_0_x4_t, calibration_conv_0_relu_x4_t, calibration_pool_0_x4_t, config3, config5>(calibration_input, layer5_out_x4, w3, b3);
    // RAVEL_OBSERVE max_pool2d_0:out0 layer5_out_x4 504
    ravel::shared_conv<calibration_pool_0_x4_t, ravel_conv2d_1_window_t, config7, 4, ravel_matrix_conv2d_1, 2>(layer5_out_x4, layer7_out);
    // RAVEL_OBSERVE conv2d_1:out0 layer7_out 156
    nnet::relu<ravel_conv2d_1_window_t, ravel_relu_1_window_t, relu_config8>(layer7_out, layer8_out);
    // RAVEL_OBSERVE relu_1:out0 layer8_out 156
    ravel::scheduled_pool<ravel_relu_1_window_t, ravel_max_pool2d_1_window_t, config9, 4>(layer8_out, layer9_out);
    // RAVEL_OBSERVE max_pool2d_1:out0 layer9_out 72
    // RAVEL_OBSERVE reshape_0:out0 layer9_out 72
    nnet::dense_wide_stream<ravel_max_pool2d_1_window_t, result_t, config11>(layer9_out, layer11_out, w11_ravel_packed, b11);
    // RAVEL_OBSERVE dense_0:out0 layer11_out 1
}
