#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <array>
#include <cstddef>
#include <cstdio>
#include <tuple>
#include <tuple>


// hls-fpga-machine-learning insert numbers

// hls-fpga-machine-learning insert layer-precision
typedef nnet::array<ap_fixed<9,5,AP_RND,AP_SAT_SYM,0>, 1*1> calibration_input_t;
typedef ap_fixed<15,7> calibration_conv_0_accum_t;
typedef nnet::array<ap_fixed<15,7>, 3*1> calibration_conv_0_t;
typedef ap_fixed<5,1> calibration_conv_0_weight_t;
typedef ap_ufixed<2,32> calibration_conv_0_bias_t;
typedef nnet::array<ap_ufixed<14,6>, 3*1> calibration_conv_0_relu_t;
typedef ap_fixed<18,8> calibration_conv_0_relu_table_t;
typedef ap_ufixed<14,6> calibration_pool_0_accum_t;
typedef nnet::array<ap_fixed<9,5,AP_RND,AP_SAT_SYM,0>, 3*1> calibration_pool_0_t;
typedef ap_fixed<15,7> calibration_conv_1_accum_t;
typedef nnet::array<ap_fixed<15,7>, 3*1> calibration_conv_1_t;
typedef ap_fixed<5,1> calibration_conv_1_weight_t;
typedef ap_ufixed<2,32> calibration_conv_1_bias_t;
typedef nnet::array<ap_ufixed<14,6>, 3*1> calibration_conv_1_relu_t;
typedef ap_fixed<18,8> calibration_conv_1_relu_table_t;
typedef ap_ufixed<14,6> calibration_pool_1_accum_t;
typedef nnet::array<ap_ufixed<14,6>, 3*1> calibration_pool_1_t;
typedef ap_fixed<22,10> calibration_head_accum_t;
typedef nnet::array<ap_fixed<22,10>, 1*1> result_t;
typedef ap_fixed<5,1> calibration_head_weight_t;
typedef ap_ufixed<2,32> calibration_head_bias_t;
typedef ap_uint<1> layer11_index;

// hls-fpga-machine-learning insert emulator-defines

// RAVEL Aria wide-stream types.
typedef nnet::array<ap_fixed<9,5,AP_RND,AP_SAT_SYM,0>, 8*4> calibration_input_x8_t;
typedef nnet::array<ap_fixed<15,7>, 12> calibration_conv_0_x4_t;
typedef nnet::array<ap_ufixed<14,6>, 12> calibration_conv_0_relu_x4_t;
typedef nnet::array<ap_fixed<9,5,AP_RND,AP_SAT_SYM,0>, 12> calibration_pool_0_x4_t;

typedef nnet::array<ap_fixed<15,7>, 12> ravel_conv2d_1_window_t;
typedef nnet::array<ap_ufixed<14,6>, 12> ravel_relu_1_window_t;
typedef nnet::array<ap_ufixed<14,6>, 12> ravel_max_pool2d_1_window_t;
#endif
