#ifndef RAVEL_170_REFRESH_FIXTURE_BRIDGE_H_
#define RAVEL_170_REFRESH_FIXTURE_BRIDGE_H_

#include "firmware/ravel_170_refresh_fixture.h"
#include "firmware/nnet_utils/nnet_helpers.h"
#include <cstdlib>
#include <map>
#include <string>

namespace nnet {
bool trace_enabled = false;
std::map<std::string, void *> *trace_outputs = NULL;
size_t trace_type_size = sizeof(double);
} // namespace nnet

template <typename scalar_T>
void pack_aria_input(scalar_T *logical_input, hls::stream<renamed_input_x2_t> &packed_input) {
    for (unsigned word_index = 0; word_index < 32; word_index++) {
        renamed_input_x2_t word;
        for (unsigned row = 0; row < 2; row++) {
            for (unsigned channel = 0; channel < 2; channel++) {
                word[row * 2 + channel] = logical_input[(word_index * 2 + row) * 2 + channel];
            }
        }
        packed_input.write(word);
    }
}

extern "C" {

struct trace_data {
    const char *name;
    void *data;
};

void allocate_trace_storage(size_t element_size) {
    nnet::trace_enabled = true;
    nnet::trace_outputs = new std::map<std::string, void *>;
    nnet::trace_type_size = element_size;
}

void free_trace_storage() {
    if (nnet::trace_outputs == NULL) {
        return;
    }
    for (std::map<std::string, void *>::iterator item = nnet::trace_outputs->begin();
         item != nnet::trace_outputs->end(); item++) {
        free(item->second);
    }
    delete nnet::trace_outputs;
    nnet::trace_outputs = NULL;
    nnet::trace_enabled = false;
}

void collect_trace_output(struct trace_data *outputs) {
    int index = 0;
    for (std::map<std::string, void *>::iterator item = nnet::trace_outputs->begin();
         item != nnet::trace_outputs->end(); item++) {
        outputs[index].name = item->first.c_str();
        outputs[index].data = item->second;
        index++;
    }
}

void ravel_170_refresh_fixture_float(float *renamed_input, float *layer11_out) {
    hls::stream<renamed_input_x2_t> renamed_input_ap("renamed_input");
    pack_aria_input(renamed_input, renamed_input_ap);
    hls::stream<result_t> layer11_out_ap("layer11_out");
    ravel_170_refresh_fixture(renamed_input_ap, layer11_out_ap);
    nnet::convert_data<result_t, float, 1>(layer11_out_ap, layer11_out);
}

void ravel_170_refresh_fixture_double(double *renamed_input, double *layer11_out) {
    hls::stream<renamed_input_x2_t> renamed_input_ap("renamed_input");
    pack_aria_input(renamed_input, renamed_input_ap);
    hls::stream<result_t> layer11_out_ap("layer11_out");
    ravel_170_refresh_fixture(renamed_input_ap, layer11_out_ap);
    nnet::convert_data<result_t, double, 1>(layer11_out_ap, layer11_out);
}

} // extern "C"

#endif
