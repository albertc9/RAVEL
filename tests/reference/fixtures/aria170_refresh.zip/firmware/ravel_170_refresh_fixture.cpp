#include "ravel_170_refresh_fixture.h"
#include "parameters.h"
#include "nnet_utils/nnet_aria.h"
#include "nnet_utils/ravel_bridges.h"
#include "weights/w11_ravel_packed.h"
void ravel_170_refresh_fixture(hls::stream<renamed_input_x2_t> &renamed_input, hls::stream<result_t> &layer11_out) {
    #pragma HLS INTERFACE axis port=renamed_input,layer11_out
    #pragma HLS DATAFLOW
#ifndef __SYNTHESIS__
    static bool loaded = false;
    if (!loaded) {
        nnet::load_weights_from_txt<renamed_conv_0_bias_t, 3>(b3, "b3.txt");
        nnet::load_weights_from_txt<renamed_conv_0_weight_t, 9>(w3, "w3.txt");
        nnet::load_weights_from_txt<renamed_conv_1_bias_t, 3>(b7, "b7.txt");
        nnet::load_weights_from_txt<renamed_conv_1_weight_t, 27>(w7, "w7.txt");
        nnet::load_weights_from_txt<renamed_head_bias_t, 1>(b11, "b11.txt");
        nnet::load_weights_from_txt<renamed_head_weight_t, 18>(w11, "w11.txt");
        loaded = true;
    }
#endif
    hls::stream<renamed_pool_0_x2_t> layer5_out_x2("layer5_out_x2");
    #pragma HLS STREAM variable=layer5_out_x2 depth=4
    hls::stream<renamed_conv_0_x2_t> layer3_out_x2("layer3_out_x2");
    #pragma HLS STREAM variable=layer3_out_x2 depth=4
    hls::stream<renamed_conv_0_relu_x2_t> layer4_out_x2("layer4_out_x2");
    #pragma HLS STREAM variable=layer4_out_x2 depth=4
    hls::stream<ravel_bridge_0_t> ravel_bridge_0("ravel_bridge_0");
    #pragma HLS STREAM variable=ravel_bridge_0 depth=4
    hls::stream<renamed_conv_1_t> layer7_out("layer7_out");
    #pragma HLS STREAM variable=layer7_out depth=4
    hls::stream<renamed_conv_1_relu_t> layer8_out("layer8_out");
    #pragma HLS STREAM variable=layer8_out depth=4
    hls::stream<renamed_pool_1_t> layer9_out("layer9_out");
    #pragma HLS STREAM variable=layer9_out depth=4
    hls::stream<ravel_bridge_1_t> ravel_bridge_1("ravel_bridge_1");
    #pragma HLS STREAM variable=ravel_bridge_1 depth=4
    nnet::first_conv_2row_4lane_temporal_wide_cl<renamed_input_x2_t, renamed_conv_0_x2_t, config3>(renamed_input, layer3_out_x2, w3, b3);
    // RAVEL_OBSERVE conv2d_0:out0 layer3_out_x2 186
    nnet::relu<renamed_conv_0_x2_t, renamed_conv_0_relu_x2_t, relu_config4>(layer3_out_x2, layer4_out_x2);
    // RAVEL_OBSERVE relu_0:out0 layer4_out_x2 186
    nnet::maxpool2d_wide_nonoverlap_cl<renamed_conv_0_relu_x2_t, renamed_pool_0_x2_t, config5>(layer4_out_x2, layer5_out_x2);
    // RAVEL_OBSERVE max_pool2d_0:out0 layer5_out_x2 90
    ravel::repack<renamed_pool_0_x2_t, ravel_bridge_0_t, 90, 3>(layer5_out_x2, ravel_bridge_0);
    // RAVEL_OBSERVE max_pool2d_0:out0 ravel_bridge_0 90
    nnet::conv_2d_cl<renamed_pool_0_t, renamed_conv_1_t, config7>(ravel_bridge_0, layer7_out, w7, b7);
    // RAVEL_OBSERVE conv2d_1:out0 layer7_out 42
    nnet::relu<renamed_conv_1_t, renamed_conv_1_relu_t, relu_config8>(layer7_out, layer8_out);
    // RAVEL_OBSERVE relu_1:out0 layer8_out 42
    nnet::pooling2d_cl<renamed_conv_1_relu_t, renamed_pool_1_t, config9>(layer8_out, layer9_out);
    // RAVEL_OBSERVE max_pool2d_1:out0 layer9_out 18
    // RAVEL_OBSERVE reshape_0:out0 layer9_out 18
    ravel::repack<renamed_pool_1_t, ravel_bridge_1_t, 18, 3>(layer9_out, ravel_bridge_1);
    // RAVEL_OBSERVE reshape_0:out0 ravel_bridge_1 18
    nnet::dense_wide_stream<ravel_bridge_1_t, result_t, config11>(ravel_bridge_1, layer11_out, w11_ravel_packed, b11);
    // RAVEL_OBSERVE dense_0:out0 layer11_out 1
}
