//Numpy array shape [3, 1, 1, 3]
//Min -0.312500000000
//Max 0.625000000000
//Number of zeros 1

#ifndef W3_H_
#define W3_H_

#ifndef __SYNTHESIS__
renamed_conv_0_weight_t w3[9];
#else
renamed_conv_0_weight_t w3[9] = {-0.3125, 0.2500, -0.3125, 0.1875, 0.6250, 0.0000, 0.1875, 0.1250, 0.6250};

#endif

#endif
