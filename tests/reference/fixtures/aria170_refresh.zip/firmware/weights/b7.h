//Numpy array shape [3]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 3

#ifndef B7_H_
#define B7_H_

#ifndef __SYNTHESIS__
renamed_conv_1_bias_t b7[3];
#else
renamed_conv_1_bias_t b7[3] = {0, 0, 0};

#endif

#endif
