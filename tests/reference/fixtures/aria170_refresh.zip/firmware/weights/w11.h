//Numpy array shape [18, 1]
//Min -0.562500000000
//Max 0.562500000000
//Number of zeros 2

#ifndef W11_H_
#define W11_H_

#ifndef __SYNTHESIS__
renamed_head_weight_t w11[18];
#else
renamed_head_weight_t w11[18] = {0.0000, 0.0000, 0.1250, -0.3750, 0.1875, 0.5000, 0.1875, -0.4375, -0.0625, -0.5625, 0.3750, 0.3750, -0.3750, 0.5625, 0.0625, 0.4375, 0.4375, 0.1250};

#endif

#endif
