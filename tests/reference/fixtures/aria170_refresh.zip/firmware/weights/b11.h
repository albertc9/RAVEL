//Numpy array shape [1]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 1

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
renamed_head_bias_t b11[1];
#else
renamed_head_bias_t b11[1] = {0};

#endif

#endif
