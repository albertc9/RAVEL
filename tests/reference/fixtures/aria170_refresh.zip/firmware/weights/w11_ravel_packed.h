#ifndef RAVEL_W11_PACKED_H_
#define RAVEL_W11_PACKED_H_

#include "ap_int.h"

const ap_uint<15> w11_ravel_packed[6] = {
    ap_uint<15>("0x0800", 16),
    ap_uint<15>("0x207a", 16),
    ap_uint<15>("0x7f23", 16),
    ap_uint<15>("0x18d7", 16),
    ap_uint<15>("0x053a", 16),
    ap_uint<15>("0x08e7", 16)
};

#endif
