#ifndef DEFINES_H_
#define DEFINES_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "nnet_utils/nnet_types.h"
#include <array>
#include <cstddef>
#include <cstdio>
#include <tuple>
#include <tuple>


// hls-fpga-machine-learning insert numbers

// hls-fpga-machine-learning insert layer-precision
typedef nnet::array<ap_fixed<9,5,AP_RND,AP_SAT_SYM,0>, 1*1> renamed_input_t;
typedef ap_fixed<13,5> renamed_conv_0_accum_t;
typedef nnet::array<ap_fixed<13,5>, 3*1> renamed_conv_0_t;
typedef ap_fixed<5,1> renamed_conv_0_weight_t;
typedef ap_ufixed<2,32> renamed_conv_0_bias_t;
typedef nnet::array<ap_ufixed<12,4>, 3*1> renamed_conv_0_relu_t;
typedef ap_fixed<18,8> renamed_conv_0_relu_table_t;
typedef ap_ufixed<12,4> renamed_pool_0_accum_t;
typedef nnet::array<ap_fixed<9,5,AP_RND,AP_SAT_SYM,0>, 3*1> renamed_pool_0_t;
typedef ap_fixed<15,7> renamed_conv_1_accum_t;
typedef nnet::array<ap_fixed<15,7>, 3*1> renamed_conv_1_t;
typedef ap_fixed<5,1> renamed_conv_1_weight_t;
typedef ap_ufixed<2,32> renamed_conv_1_bias_t;
typedef nnet::array<ap_ufixed<14,6>, 3*1> renamed_conv_1_relu_t;
typedef ap_fixed<18,8> renamed_conv_1_relu_table_t;
typedef ap_ufixed<14,6> renamed_pool_1_accum_t;
typedef nnet::array<ap_ufixed<14,6>, 3*1> renamed_pool_1_t;
typedef ap_fixed<21,9> renamed_head_accum_t;
typedef nnet::array<ap_fixed<21,9>, 1*1> result_t;
typedef ap_fixed<5,1> renamed_head_weight_t;
typedef ap_ufixed<2,32> renamed_head_bias_t;
typedef ap_uint<1> layer11_index;

// hls-fpga-machine-learning insert emulator-defines

// RAVEL Aria wide-stream types.
typedef nnet::array<ap_fixed<9,5,AP_RND,AP_SAT_SYM,0>, 2*2> renamed_input_x2_t;
typedef nnet::array<ap_fixed<13,5>, 6> renamed_conv_0_x2_t;
typedef nnet::array<ap_ufixed<12,4>, 6> renamed_conv_0_relu_x2_t;
typedef nnet::array<ap_fixed<9,5,AP_RND,AP_SAT_SYM,0>, 6> renamed_pool_0_x2_t;

typedef nnet::array<ap_fixed<15,7>, 6> ravel_conv2d_1_window_t;
typedef nnet::array<ap_ufixed<14,6>, 6> ravel_relu_1_window_t;
typedef nnet::array<ap_ufixed<14,6>, 6> ravel_max_pool2d_1_window_t;
#endif
