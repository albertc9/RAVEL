#ifndef ARIA171_FIXTURE_H_
#define ARIA171_FIXTURE_H_

#include "ap_fixed.h"
#include "ap_int.h"
#include "hls_stream.h"

#include "defines.h"

void aria171_fixture(
    hls::stream<renamed_input_x2_t> &renamed_input,
    hls::stream<result_t> &layer11_out
);

#endif
