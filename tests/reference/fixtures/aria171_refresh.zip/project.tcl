variable project_name
set project_name "aria171_fixture"
variable backend
set backend "vitis"
variable part
set part "xcku5p-ffvb676-2-e"
variable clock_period
set clock_period 5
variable clock_uncertainty
set clock_uncertainty 27%
variable version
set version "1.0.0"
variable maximum_size
set maximum_size 4096
